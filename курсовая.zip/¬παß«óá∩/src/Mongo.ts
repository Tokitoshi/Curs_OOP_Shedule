import { MongoClient } from 'mongodb'
import { writeFileSync } from 'fs'
import { Schedule } from './rasp_from_excel'
import ejs from 'ejs'
import path from 'path'

const CONNECTION = 'mongodb://root:example@127.0.0.1:27017/'
const client = new MongoClient(CONNECTION, { monitorCommands: true })

export const initializeMongo = async () => {
    try {
        await client.connect()
        console.log('Подключение к БД')
    } catch (error) {
        console.error('Ошибка при подключении к БД', error)
        throw error
    }
}

export const closeMongo = async () => {
    try {
        await client.close()
        console.log('Отключение от БД')
    } catch (error) {
        console.error('Ошибка при отключении от БД', error)
        throw error
    }
}

export const insertScheduleToDB = async (schedule: Schedule[]) => {
  try {
      await client.connect()
      const db = client.db('KRB')
      const collection = db.collection('Lesson')
      collection.drop()
      await collection.insertMany(schedule)
      console.log('Расписание успешно вставлено в базу данных')
  } catch (error) {
      console.error('Ошибка при вставке расписания в базу данных', error)
      throw error
  } finally {
      await client.close()
  }
};

export const getSchedule = async (criteria: { type: string; value: string }) => {
  try {
      await client.connect();
      const db = client.db('KRB');
      const collection = db.collection('Lesson');
      const { type, value } = criteria;
      const daysOfWeek = ['понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'];
      let matchCondition;
          matchCondition = {
              $or: daysOfWeek.map(day => ({
                  [`days.day`]: day,
                  [`days.lessons.${type}`]: { $regex: new RegExp(`(^|;|~)${value}($|;|~)`, 'i') }
              }))
          };
      const schedule = await collection.aggregate([
          { $match: matchCondition },
          { $unwind: "$days" },
          { $unwind: "$days.lessons" },
          {
              $match: {
                  [`days.lessons.${type}`]: { $regex: new RegExp(`(^|;|~)${value}($|;|~)`, 'i') }
              }
          },
          {
              $project: {
                  week: 1,
                  dayOfWeek: "$days.day",
                  time: "$days.lessons.time",
                  teacher: "$days.lessons.teacher",
                  group: "$days.lessons.group",
                  classroom: "$days.lessons.classroom",
                  subjectType: "$days.lessons.subjectType",
                  subjectName: "$days.lessons.subjectName",
                  dayOfWeekNumber: { $indexOfArray: [daysOfWeek, "$days.day"] }
              }
          },
          {$sort: {week: -1, dayOfWeekNumber: 1, time: 1}}
      ]).toArray()
      return schedule
  } catch (error) {
      console.error('Ошибка при получении расписания', error)
      throw error
  } 
}

export const showSchedule = async (criteria: { type: string, value: string }[]) => {
    try {
        console.log(`Расписание для критериев: ${criteria.map(({ type, value }) => `${type}: ${value}`).join(', ')}`)
    } catch (error) {
        console.error('Ошибка:', error)
    }
}

export async function insertHTML(criteria: { type: string, value: string }[]) {
  try {
      console.log('Запись данных в HTML из MONGO')
      const data = await Promise.all(criteria.map(async criterion => {
        return await getSchedule(criterion)
    }))
      const templatePath = criteria.find(c => c.type === 'group') ? path.resolve(__dirname, 'index_group.ejs') :
                            criteria.find(c => c.type === 'classroom') ? path.resolve(__dirname, 'index_aud.ejs') :
                            criteria.find(c => c.type === 'teacher') ? path.resolve(__dirname, 'index_prep.ejs') :
                            path.resolve(__dirname, 'index.ejs')
      const htmlContent = await ejs.renderFile(templatePath, { schedule: data })
      writeFileSync('schedule_data.html', htmlContent)
      console.log('Данные из MongoDB записаны в файл HTML')
  } catch (error) {
      console.error('Ошибка при генерации HTML:', error)
  }
}