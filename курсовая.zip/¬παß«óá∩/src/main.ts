import path from 'path'
import readline from 'readline'
import { initializeMongo, closeMongo, insertScheduleToDB, showSchedule, insertHTML } from './Mongo'
import { parseSchedule } from './rasp_from_excel'

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
})

const askQuestion = (query: string): Promise<string> => {
    return new Promise(resolve => rl.question(query, resolve))
}

const criteriaMapping: { [key: string]: string } = {
    '1': 'teacher',
    '2': 'group',
    '3': 'classroom',
}

const main = async () => {
    try {
        await initializeMongo()
        const filePath = path.resolve('src/Автоматика и системы.xlsx')
        const schedule = await parseSchedule(filePath)
        await insertScheduleToDB(schedule)
        const criteria = []
        let checkNumberOfConditions: number
        while (true) {
            const numberOfConditions = await askQuestion("Укажите количество значений для поиска: ")
            checkNumberOfConditions = parseInt(numberOfConditions, 10)
            if (!isNaN(checkNumberOfConditions) && checkNumberOfConditions > 0) {
                break
            }
            console.log("Введите корректное число значений")
        }
        for (let i = 0; i < checkNumberOfConditions; i++) {
            const type = (await askQuestion('Введите тип поиска: \n1 - преподаватель\n2 - группа\n3 - аудитория\n')).toLowerCase()
            const value = await askQuestion('Введите значение для поиска:\n')
            const mappedType = criteriaMapping[type]
            if (!mappedType) {
                console.log(`Неправильный тип поиска: ${type}`)
                await closeMongo()
                rl.close()
                return
            }
            criteria.push({ type: mappedType, value })
        }
        await showSchedule(criteria)
        await insertHTML(criteria)
    } catch (error) {
        console.error('Ошибка:', error)
    } finally {
        await closeMongo()
        rl.close()
    }
}
main().catch(console.error)